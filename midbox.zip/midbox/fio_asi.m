function asi = fio_asi(x, fx)
% fio_asi  Asymmetry of nonlinearity
% 
%    fio_asi(x,fx) takes in the nonlinearity fx, and the bin values x,
%    and computes the asymmetry of fx. Asymmetry is calculated by
%    comparing values greater than 0 to those less than 0. The 
%    calculation is asi = (right - left) / (right + left)
% 
%    caa 10/18/2011

indexright = find(x>0);
indexleft = find(x<0);

right = sum( fx(indexright) - min(fx) );
left = sum( fx(indexleft) - min(fx) );

asi = (right - left) / (right + left);

return;