function [ifrac] = info_fraction(locator, x, xbins, frac)
%info_fraction - filter information for different data fractions
%
% [ifrac] = info_fraction_2d(locator, x, xbins, frac)
% -------------------------------------------------------
%
% locator : vector listing number of spikes for a given trial
%
% x : projection values onto a filter. A vector.
%
% xbins : center of bins at which projection probability distributions
% will be calculated
%
% frac : data fraction for which information will be estimated. A scalar, 
% usually something like 80 or 92.5
%
% ifrac : data fraction information estimates. 1x5 vector. 5 estimates 
% 
% caa 3/10/09


frac = frac / 100;

nreps = 5;

ntrials = length(locator);

nfrac = round(frac * ntrials); % number of reduced trials

ifrac = zeros(1,nreps);

rand('state', 0);

for i = 1:nreps

   first = ceil( rand(1) * (ntrials-nfrac+1) );
   last = first + nfrac - 1;

   index_trials = first:last;

   locator_temp = locator( index_trials );
   xtemp = x( index_trials );
   xspktemp = xtemp( locator_temp > 0);

   % Now normalize by the mean and std of the prior
   xmn = mean(xtemp);
   xstd = std(xtemp);

   xtemp = (xtemp - xmn) ./ xstd;
   xspktemp = (xspktemp - xmn) ./ xstd;


   % Form the probability distributions
   nx = hist(xtemp, xbins);
   px = nx ./ sum(nx); % p(x)
   px = px(:);

   nxspk = hist(xspktemp, xbins);
   pxspk = nxspk ./ sum( nxspk ); % p(x|spk)
   pxspk = pxspk(:);

   % Get and assign the information
   iplugin = info_px_pxspk(px, pxspk);

   ifrac(i) = iplugin;

end % (for i)

return;








