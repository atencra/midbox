function [xbins, pspk, px1x2, px1x2spk, pspkx1x2] = proj_prob_dist_2d(xtrain_locator, xtrain_mid1, xtrain_mid2)
%proj_prob_dist_2d - 2D probability distributions for projection values
%
% For each training data set, we caclulate the probability of a spike, 
% the probability of a projection without respect to a spike, the 
% probability of a projection when a spike occurs, and the probability of
% a spike given a projection value. This last distribution is the 
% nonlinearity for a neuron.
%
% [xbins, pspk, px1x2, px1x2spk, pspkx1x2] = proj_prob_dist_2d(xtrain_locator, xtrain_mid1, xtrain_mid2)
% ------------------------------------------------------------------------
%
% Input arguments:
%
% xtrain_locator : 1x4 cell array. The locator for each training set. A
% locator is vector whose length is as long as the number of trials in
% a training set. Elements in locator are >= 0, depending on how many 
% spikes occurred during a given trial.
%
% xtrain_mid1 : 1x4 cell array. Each element represents the projection values
% onto one of the training set mid1 filters.
% 
% xtrain_mid2 : 1x4 cell array. Each element represents the projection values
% onto one of the training set mid2 filters.
%
%
% Output arguments:
%
% xbins : the values at which the probability distributions are binned.
% Values of xbins are usually -7:7. These represents normalized units,
% since the projections are normalized relative to the mean and standard
% deviation of the probability of projection without regard to a spike.
%
% pspk : 1x4 cell array. Each element is the probability of a spike 
% during one of the training sets.
%
% px : 1x4 cell array. An element is the probability of a projection 
% value for a training set. 
%
% pxspk : 1x4 cell array. An element is the probability of a projection 
% value given a spike for a training set. 
% 
% pspkx : 1x4 cell array. An element is the probability of a spike
% given a projection for a training set. 
%
% caa 3/11/09


fprintf('\nRunning proj_prob_dist ...\n');


% Get probability distributions for training data sets

% We need to get: p(spk), p(x), p(x|spk), and p(spk|x)

binedges = -7.5:7.5;
binedges = binedges(:);
nbins = length(binedges);
xbins = 0.5*(binedges(1:(nbins-1))+binedges(2:nbins));

for i = 1:length(xtrain_mid1) % xtrain_mid1, mid2 are cell arrays

   locator = xtrain_locator{i};

   x1prior = xtrain_mid1{i};
   x2prior = xtrain_mid2{i};


   % Probability of a spike in a given trial
   nspikes = sum(locator);
   pspk_temp = nspikes / length(locator); % probability of a spike

   % MID1 : Normalize projection values to mean, sd of prior
   mean1_prior = mean(x1prior);
   std1_prior = std(x1prior);

   x1 = (x1prior - mean1_prior) ./ std1_prior;
   x1spk = x1( locator > 0 ); % values corresponding to a spike


   % MID2 : Normalize projection values to mean, sd of prior
   mean2_prior = mean(x2prior);
   std2_prior = std(x2prior);

   x2 = (x2prior - mean2_prior) ./ std2_prior;
   x2spk = x2( locator > 0 ); % values corresponding to a spike


   % Combine the data into a matrix:
   x1x2 = [x1(:) x2(:)];
   x1x2spk = [x1spk(:) x2spk(:)];


%    x1min = min( projspk_scaled(:,1) );
%    x1max = max( projspk_scaled(:,1) );
%    x1bins = linspace(x1min, x1max, numbins); % equally spaced bin edges
%    x1binedges = x1bins; %center2edge(x1bins); % make bin edges for hist2d function
% 
%    x2min = min( projspk_scaled(:,2) );
%    x2max = max( projspk_scaled(:,2) );
%    x2bins = linspace(x2min, x2max, numbins); % equally spaced bin edges
%    x2binedges = x2bins; %center2edge(x2bins); % make bin edges for hist2d function


   % Now we need to bin the projection values and obtain the probability
   % distributions:

   nx1x2spk = hist2d(x1x2spk, binedges, binedges);
   px1x2spk_temp = nx1x2spk ./ sum(sum(nx1x2spk)); % normalize


   nx1x2 = hist2d(x1x2, binedges, binedges);
   px1x2_temp = nx1x2 ./ sum(sum(nx1x2)) + eps; % normalize

   pspkx1x2_temp = pspk_temp .* px1x2spk_temp ./ px1x2_temp; % p(spk|x)

   pspk{i} = pspk_temp;
   px1x2{i} = px1x2_temp;
   px1x2spk{i} = px1x2spk_temp;
   pspkx1x2{i} = pspkx1x2_temp;

end % (for)

return;








